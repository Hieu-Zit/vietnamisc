export const sanitizeFontKey = (name = '') => name.toLowerCase().replaceAll(' ', '_');
