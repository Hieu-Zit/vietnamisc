<div class="card card-default category-card has_desc">
    <div class="card-body">
        <div class="media">
            <div class="pull-left">[icon]</div>
            <div class="media-body">
                <h3>[name]</h3>
                <p>[description]</p>
            </div>
        </div>
    </div>
</div>